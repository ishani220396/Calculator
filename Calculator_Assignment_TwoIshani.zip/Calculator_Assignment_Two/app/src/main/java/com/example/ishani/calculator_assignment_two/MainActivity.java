package com.example.ishani.calculator_assignment_two;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {


    TextView txtViewResult;
    TextView txtViewInput;

    String s = "", s1 = "", s2 = "", resultString = "";

    int i = 0, i1 = 0, c = -1;

    int result = 0;

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button One = (Button) findViewById(R.id.one);
        Button Two = (Button) findViewById(R.id.two);
        Button Three = (Button) findViewById(R.id.three);
        Button Four = (Button) findViewById(R.id.four);
        Button Five = (Button) findViewById(R.id.five);
        Button Six = (Button) findViewById(R.id.six);
        Button Seven = (Button) findViewById(R.id.seven);
        Button Eight = (Button) findViewById(R.id.eight);
        Button Nine = (Button) findViewById(R.id.nine);
        Button Zero = (Button) findViewById(R.id.zero);
        Button Add = (Button) findViewById(R.id.add);
        Button Sub = (Button) findViewById(R.id.sub);
        Button Mul = (Button) findViewById(R.id.mul);
        Button Div = (Button) findViewById(R.id.div);
        Button Clear = (Button) findViewById(R.id.clear);
        Button Ce = (Button) findViewById(R.id.ce);
        Button Equal = (Button) findViewById(R.id.equal);

        txtViewResult = (TextView) findViewById(R.id.textViewResult);
        txtViewInput = (TextView) findViewById(R.id.textViewInput);

        One.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                s = (String) txtViewResult.getText();
                if (s.equals("+") || s.equals("-") || s.equals("/")
                        || s.equals("*")) {
                    txtViewResult.setText("");
                    s = "";
                }
                txtViewResult.setText(s + "1");
                s = "";
            }
        });

        Two.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                s = (String) txtViewResult.getText();
                if (s.equals("+") || s.equals("-") || s.equals("/")
                        || s.equals("*")) {
                    txtViewResult.setText("");
                    s = "";
                }
                txtViewResult.setText(s + "2");
                s = "";
            }
        });

        Three.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                s = (String) txtViewResult.getText();
                if (s.equals("+") || s.equals("-") || s.equals("/")
                        || s.equals("*")) {
                    txtViewResult.setText("");
                    s = "";
                }
                txtViewResult.setText(s + "3");
                s = "";
            }
        });

        Four.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                s = (String) txtViewResult.getText();
                if (s.equals("+") || s.equals("-") || s.equals("/")
                        || s.equals("*")) {
                    txtViewResult.setText("");
                    s = "";
                }
                txtViewResult.setText(s + "4");
                s = "";
            }
        });

        Five.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                s = (String) txtViewResult.getText();
                if (s.equals("+") || s.equals("-") || s.equals("/")
                        || s.equals("*")) {
                    txtViewResult.setText("");
                    s = "";
                }
                txtViewResult.setText(s + "5");
                s = "";
            }
        });

        Six.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                s = (String) txtViewResult.getText();
                if (s.equals("+") || s.equals("-") || s.equals("/")
                        || s.equals("*")) {
                    txtViewResult.setText("");
                    s = "";
                }
                txtViewResult.setText(s + "6");
                s = "";
            }
        });

        Seven.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                s = (String) txtViewResult.getText();
                if (s.equals("+") || s.equals("-") || s.equals("/")
                        || s.equals("*")) {
                    txtViewResult.setText("");
                    s = "";
                }
                txtViewResult.setText(s + "7");
                s = "";
            }
        });

        Eight.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                s = (String) txtViewResult.getText();
                if (s.equals("+") || s.equals("-") || s.equals("/")
                        || s.equals("*")) {
                    txtViewResult.setText("");
                    s = "";
                }
                txtViewResult.setText(s + "8");
                s = "";
            }
        });
        Nine.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                s = (String) txtViewResult.getText();
                if (s.equals("+") || s.equals("-") || s.equals("/")
                        || s.equals("*")) {
                    txtViewResult.setText("");
                    s = "";
                }
                txtViewResult.setText(s + "9");
                s = "";
            }
        });

        Zero.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                s = (String) txtViewResult.getText();
                if (s.equals("+") || s.equals("-") || s.equals("/")
                        || s.equals("*")) {
                    txtViewResult.setText("");
                    s = "";
                }
                txtViewResult.setText(s + "0");
                s = "";
            }
        });

        Clear.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                s = (String) txtViewResult.getText();
                if (s.equals("+") || s.equals("-") || s.equals("/")
                        || s.equals("*") || s.equals("")) {
                    i = 0;
                } else {
                    i = Integer.parseInt(s);
                    i = i / 10;
                }
                if (i == 0) {
                    txtViewResult.setText("");
                } else {
                    txtViewResult.setText(i + "");
                }
                s = null;
            }
        });

        Add.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                String tmp = (String) txtViewResult.getText();
                if(tmp.isEmpty()) {
                    s1 = "0";
                } else if (!tmp.equals("+") && !tmp.equals("-") && !tmp.equals("*")
                        && !tmp.equals("/")) {
                    s1 = tmp;
                }
                c = 0;
                resultString = "";
                txtViewResult.setText("+");
                txtViewInput.setText(s1 + " + ");
            }

        });

        Sub.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                String tmp = (String) txtViewResult.getText();
                if(tmp.isEmpty()) {
                    s1 = "0";
                } else if (!tmp.equals("+") && !tmp.equals("-") && !tmp.equals("*")
                        && !tmp.equals("/")) {
                    s1 = tmp;
                }
                c = 1;
                resultString = "";
                txtViewResult.setText("-");
                txtViewInput.setText(s1 + " - ");
            }

        });

        Div.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                String tmp = (String) txtViewResult.getText();
                if(tmp.isEmpty()) {
                    s1 = "0";
                } else if (!tmp.equals("+") && !tmp.equals("-") && !tmp.equals("*")
                        && !tmp.equals("/")) {
                    s1 = tmp;
                }
                c = 2;
                resultString = "";
                txtViewResult.setText("/");
                txtViewInput.setText(s1 + " / ");
            }

        });

        Mul.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                String tmp = (String) txtViewResult.getText();
                if(tmp.isEmpty()) {
                    s1 = "0";
                } else if (!tmp.equals("+") && !tmp.equals("-") && !tmp.equals("*")
                        && !tmp.equals("/")) {
                    s1 = tmp;
                }
                c = 3;
                resultString = "";
                txtViewResult.setText("*");
                txtViewInput.setText(s1 + " * ");
            }

        });

        Ce.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                txtViewResult.setText("");
                txtViewInput.setText("");
                i = 0;
                i1 = 0;
                s1 = "";
                s2 = "";
                resultString = "";
                c = -1;
                result = 0;
            }

        });

        Equal.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String operator = "";
                if (s1.equalsIgnoreCase("+") || s1.equalsIgnoreCase("-") || s1.equalsIgnoreCase("/") || s1.equalsIgnoreCase("*")) {
                    i = 0;
                } else if (s1 == null || s1.isEmpty()) {
                    i = 0;
                } else {
                    i = Integer.parseInt(s1);
                }

                if(resultString.isEmpty()) {
                    s2 = (String) txtViewResult.getText();
                    if (s2.equalsIgnoreCase("+") || s2.equalsIgnoreCase("-") || s2.equalsIgnoreCase("/") || s2.equalsIgnoreCase("*")) {
                        i1 = 0;
                    } else if (s2 == null || s2.isEmpty()) {
                        i1 = 0;
                    } else {
                        i1 = Integer.parseInt(s2);
                    }
                } else {
                    i = result;
                }

                if (c == 0) {
                    operator = "+";
                    result = i + i1;
                } else if (c == 1) {
                    operator = "-";
                    result = i - i1;
                } else if (c == 2) {
                    operator = "/";
                    if (i1 == 0) {
                        Toast.makeText(getApplicationContext(),
                                "Invalid Input", Toast.LENGTH_LONG).show();
                        result = 0;
                    } else {
                        result = i / i1;
                    }
                } else if (c == 3) {
                    operator = "*";
                    result = i * i1;
                } else {
                    operator = "";
                    result = 0;
                }

                //History Storage
                if(!operator.isEmpty()) {
                    txtViewInput.setText(i + " " + operator + " " + i1);
                } else {
                    txtViewInput.setText("");
                }

                resultString = String.valueOf(result);
                txtViewResult.setText(resultString);
            }

        });
    }
}
